import "../global.css";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { Drawer } from "expo-router/drawer";
import { LinearGradient } from "expo-linear-gradient";
import { StyleSheet, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";

export default function Layout() {
  return (
    <GestureHandlerRootView>
      {/* Child View handles layout styling */}
      <View style={{ flex: 1 }}>
        <Drawer
          screenOptions={{
            headerShown: true,
            drawerActiveTintColor: "#22C55E",
            headerTintColor: "#fff",
            headerBackground: () => (
              <LinearGradient
                colors={["#006A4E", "#7C3AED", "#D946EF"]}
                style={StyleSheet.absoluteFill}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              />
            ),
          }}
        >
          <Drawer.Screen
            name="index"
            options={{
              title: "Home",
              drawerIcon: ({ color, size }) => (
                <Ionicons name="home-outline" size={size} color={color} />
              ),
            }}
          />
          <Drawer.Screen
            name="about"
            options={{
              title: "About",
              drawerIcon: ({ color, size }) => (
                <Ionicons name="list-outline" size={size} color={color} />
              ),
            }}
          />
          <Drawer.Screen
            name="form/addForm"
            options={{
              drawerItemStyle: { display: "none" }, // hide from drawer
              headerShown: true, // keep header visible
            }}
          />
          <Drawer.Screen
            name="form/edit/[id]"
            options={{
              drawerItemStyle: { display: "none" }, // hide from drawer
              headerShown: true, // keep header visible
            }}
          />
        </Drawer>
      </View>
    </GestureHandlerRootView>
  );
}
