import { useLayoutEffect } from "react";
import { useNavigation } from "expo-router";
import { View, Text } from "react-native"

export default function About() {
  return <View><Text>About screen</Text></View>;
}
