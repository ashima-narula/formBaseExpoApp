import React, { useState, useLayoutEffect } from "react";
import {
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  StyleSheet,
  Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter, useLocalSearchParams, useNavigation } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { api } from "../../../../lib/apiClient";
import { ENV } from "../../../../lib/env";

const { width: screenWidth, height: screenHeight } = Dimensions.get("window");

export default function AddField() {
  const router = useRouter();
  const navigation = useNavigation();
  const { id } = useLocalSearchParams(); // form id

  const [label, setLabel] = useState("");
  const [fieldType, setFieldType] = useState("");
  const [loading, setLoading] = useState(false);

  // Set up header
  useLayoutEffect(() => {
    navigation.setOptions({
      title: "➕ Add Field",
      headerStyle: { backgroundColor: "#7C3AED" },
      headerTintColor: "#fff",
      headerLeft: () => (
        <TouchableOpacity style={{ marginLeft: 15 }} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
      ),
    });
  }, [navigation]);

  const handleSubmit = async () => {
    if (!label.trim() || !fieldType.trim()) {
      Alert.alert("Error", "Both field label and type are required.");
      return;
    }

    setLoading(true);

    try {
      const payload = {
        form_id: id,
        label,
        field_type: fieldType,
      };

      await api.post("/field", payload);

      Alert.alert("Success", "Field added successfully!", [
        {
          text: "OK",
          onPress: () => router.back(),
        },
      ]);
    } catch (err) {
      console.error(err);
      Alert.alert("Error", "Failed to add field.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      {/* Field Label */}
      <View style={[styles.inputContainer, { marginBottom: screenHeight * 0.03 }]}>
        <Text style={styles.label}>Field Label</Text>
        <TextInput
          value={label}
          onChangeText={setLabel}
          placeholder="Enter field label"
          style={styles.input}
          editable={!loading}
        />
      </View>

      {/* Field Type */}
      <View style={[styles.inputContainer, { marginBottom: screenHeight * 0.04 }]}>
        <Text style={styles.label}>Field Type</Text>
        <TextInput
          value={fieldType}
          onChangeText={setFieldType}
          placeholder="e.g. text, multiline, dropdown"
          style={styles.input}
          editable={!loading}
        />
        <Text style={styles.hint}>Supported types: text, multiline, number, dropdown, image</Text>
      </View>

      {/* Save Button */}
      <TouchableOpacity
        activeOpacity={0.85}
        onPress={handleSubmit}
        style={[styles.buttonWrapper, { marginTop: screenHeight * 0.025 }]}
        disabled={loading}
      >
        <LinearGradient
          colors={loading ? ["#A78BFA", "#F9A8D4"] : ["#7C3AED", "#D946EF"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={[styles.buttonGradient, { height: screenHeight * 0.06 }]}
        >
          {loading ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <Text style={styles.buttonText}>Add Field</Text>
          )}
        </LinearGradient>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F9FAFB",
    paddingHorizontal: screenWidth * 0.06,
    paddingVertical: screenHeight * 0.03,
  },
  inputContainer: {},
  label: {
    fontSize: screenWidth * 0.045,
    color: "#374151",
    fontWeight: "500",
    marginBottom: screenHeight * 0.01,
  },
  input: {
    backgroundColor: "#fff",
    padding: screenHeight * 0.02,
    borderRadius: screenWidth * 0.04,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    fontSize: screenWidth * 0.045,
    color: "#111827",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 2,
  },
  hint: {
    color: "#6B7280",
    fontSize: screenWidth * 0.035,
    marginTop: 5,
  },
  buttonWrapper: {
    borderRadius: screenWidth * 0.06,
    overflow: "hidden",
  },
  buttonGradient: {
    alignItems: "center",
    justifyContent: "center",
    borderRadius: screenWidth * 0.06,
    paddingHorizontal: screenWidth * 0.05,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: screenWidth * 0.048,
  },
});
