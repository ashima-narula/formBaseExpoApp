// app/form/[id]/fields/index.tsx
import React, { useEffect, useState } from "react";
import { View, Text, TextInput, Button, ScrollView, TouchableOpacity } from "react-native";
import { Picker } from "@react-native-picker/picker"; // ✅ Correct import
import { useRouter, useLocalSearchParams } from "expo-router"; // ✅ Corrected import

type FieldType = "text" | "multiline" | "dropdown" | "location" | "image";

interface FormField {
  id: number;
  label: string;
  field_type: FieldType;
  options?: string[];
  required?: boolean;
}

export default function FormFieldsScreen() {
  const { id: formId } = useLocalSearchParams<{ id: string }>(); // ✅ Corrected usage
  const router = useRouter();

  const [fields, setFields] = useState<FormField[]>([]);
  const [newField, setNewField] = useState<Partial<FormField>>({
    label: "",
    field_type: "text",
    options: [],
    required: false,
  });

  useEffect(() => {
    // Fetch existing fields for this form
    fetch(`https://your-api.com/form_fields?form_id=eq.${formId}`)
      .then((res) => res.json())
      .then((data) => setFields(data))
      .catch((err) => console.error(err));
  }, [formId]);

  const addField = async () => {
    if (!newField.label || !newField.field_type) return;

    // Optional: handle dropdown options as comma-separated string
    if (newField.field_type === "dropdown" && typeof newField.options === "string") {
      newField.options = (newField.options as string).split(",").map((o) => o.trim());
    }

    const fieldToAdd = { ...newField, form_id: Number(formId) };

    // Simulate API POST
    const response = await fetch("https://your-api.com/form_fields", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(fieldToAdd),
    });
    const savedField = await response.json();

    setFields([...fields, savedField]);
    setNewField({ label: "", field_type: "text", options: [], required: false });
  };

  const handleOptionChange = (text: string) => {
    setNewField({ ...newField, options: text.split(",").map((o) => o.trim()) });
  };

  return (
    <ScrollView style={{ padding: 16 }}>
      <Text style={{ fontSize: 20, fontWeight: "bold", marginBottom: 12 }}>
        Manage Fields for Form {formId}
      </Text>

      {/* New Field Form */}
      <View style={{ marginBottom: 24 }}>
        <Text>Label:</Text>
        <TextInput
          placeholder="Field label"
          value={newField.label}
          onChangeText={(text) => setNewField({ ...newField, label: text })}
          style={{ borderWidth: 1, padding: 8, borderRadius: 6, marginBottom: 12 }}
        />

        <Text>Type:</Text>
        <Picker
          selectedValue={newField.field_type}
          onValueChange={(val) => setNewField({ ...newField, field_type: val as FieldType })}
          style={{ marginBottom: 12 }}
        >
          <Picker.Item label="Text" value="text" />
          <Picker.Item label="Multiline" value="multiline" />
          <Picker.Item label="Dropdown" value="dropdown" />
          <Picker.Item label="Location" value="location" />
          <Picker.Item label="Image" value="image" />
        </Picker>

        {newField.field_type === "dropdown" && (
          <>
            <Text>Options (comma separated):</Text>
            <TextInput
              placeholder="Option1, Option2"
              value={newField.options?.join(",") || ""}
              onChangeText={handleOptionChange}
              style={{ borderWidth: 1, padding: 8, borderRadius: 6, marginBottom: 12 }}
            />
          </>
        )}

        <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 12 }}>
          <Text>Required: </Text>
          <TouchableOpacity
            onPress={() => setNewField({ ...newField, required: !newField.required })}
            style={{
              padding: 8,
              backgroundColor: newField.required ? "green" : "gray",
              borderRadius: 6,
            }}
          >
            <Text style={{ color: "#fff" }}>{newField.required ? "Yes" : "No"}</Text>
          </TouchableOpacity>
        </View>

        <Button title="Add Field" onPress={addField} />
      </View>

      {/* Existing Fields List */}
      <Text style={{ fontSize: 18, fontWeight: "bold", marginBottom: 12 }}>Existing Fields:</Text>
      {fields.map((f) => (
        <View
          key={f.id}
          style={{ padding: 12, borderWidth: 1, borderRadius: 8, marginBottom: 8 }}
        >
          <Text style={{ fontWeight: "bold" }}>{f.label}</Text>
          <Text>Type: {f.field_type}</Text>
          {f.field_type === "dropdown" && <Text>Options: {f.options?.join(", ")}</Text>}
          <Text>Required: {f.required ? "Yes" : "No"}</Text>
        </View>
      ))}
    </ScrollView>
  );
}
