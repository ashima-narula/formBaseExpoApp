// app/form/[id]/responses.tsx
import React, { useEffect, useState, useLayoutEffect } from "react";
import { View, Text, ScrollView, ActivityIndicator, Alert, StyleSheet, Dimensions } from "react-native";
import { useRouter, useLocalSearchParams, useNavigation } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { api } from "../../../lib/apiClient";

const { width, height } = Dimensions.get("window");

export default function Responses() {
  const router = useRouter();
  const navigation = useNavigation();
  const { id } = useLocalSearchParams();

  const [responses, setResponses] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useLayoutEffect(() => {
    navigation.setOptions({
      title: "📊 Form Responses",
      headerStyle: { backgroundColor: "#7C3AED" },
      headerTintColor: "#fff",
      headerLeft: () => (
        <Ionicons
          name="arrow-back"
          size={24}
          color="#fff"
          style={{ marginLeft: 15 }}
          onPress={() => router.back()}
        />
      ),
    });
  }, [navigation]);

  const fetchResponses = async () => {
    setLoading(true);
    try {
      const res = await api.get(`/record`, { form_id: `eq.${id}` });
      // @ts-ignore
      setResponses(res);
    } catch (e) {
      console.error(e);
      Alert.alert("Error", "Failed to load responses");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResponses();
  }, [id]);

  if (loading) return <ActivityIndicator style={{ marginTop: height * 0.4 }} size="large" color="#7C3AED" />;

  if (!responses.length)
    return (
      <View style={styles.empty}>
        <Text style={styles.emptyText}>No responses found yet.</Text>
      </View>
    );

  return (
    <ScrollView style={styles.container}>
      {responses.map((r, i) => (
        <View key={i} style={styles.card}>
          <Text style={styles.title}>Response #{i + 1}</Text>
          <Text style={styles.body}>{JSON.stringify(r.values, null, 2)}</Text>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F9FAFB", padding: width * 0.05 },
  card: {
    backgroundColor: "#fff",
    padding: 16,
    borderRadius: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  title: { fontWeight: "600", fontSize: 18, marginBottom: 6, color: "#111827" },
  body: { color: "#4B5563", fontFamily: "monospace" },
  empty: { flex: 1, alignItems: "center", justifyContent: "center", marginTop: height * 0.3 },
  emptyText: { color: "#9CA3AF", fontSize: 18 },
});
