// app/form/[id]/submit.tsx
import React, { useEffect, useState, useLayoutEffect } from "react";
import { ScrollView, TouchableOpacity, ActivityIndicator, StyleSheet, Dimensions, Alert } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter, useLocalSearchParams, useNavigation } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { api } from "../../../lib/apiClient";
import { ENV } from "../../../lib/env";
import FieldRenderer from "../../../components/FieldRenderer";

const { width: screenWidth, height: screenHeight } = Dimensions.get("window");

export default function SubmitForm() {
  const router = useRouter();
  const navigation = useNavigation();
  const { id } = useLocalSearchParams();

  const [fields, setFields] = useState<any[]>([]);
  const [values, setValues] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(false);

  useLayoutEffect(() => {
    navigation.setOptions({
      title: "📝 Fill Out Form",
      headerStyle: { backgroundColor: "#7C3AED" },
      headerTintColor: "#fff",
      headerLeft: () => (
        <TouchableOpacity style={{ marginLeft: 15 }} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
      ),
    });
  }, [navigation]);

  const fetchFields = async () => {
    setLoading(true);
    try {
      const res = await api.get(`/field`, { form_id: `eq.${id}` });
      // @ts-ignore
      setFields(res);
    } catch (e) {
      console.error(e);
      Alert.alert("Error", "Failed to load form fields.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      await api.post("/record", {
        form_id: id,
        username: ENV.VITE_USERNAME,
        values,
      });
      Alert.alert("Success", "Response submitted successfully!", [
        { text: "OK", onPress: () => router.back() },
      ]);
    } catch (e) {
      console.error(e);
      Alert.alert("Error", "Failed to submit form.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFields();
  }, [id]);

  if (loading && fields.length === 0)
    return <ActivityIndicator style={{ marginTop: screenHeight * 0.4 }} size="large" color="#7C3AED" />;

  return (
    <ScrollView style={styles.container}>
      {fields.map((field) => (
        <FieldRenderer
          key={field.id}
          field={field}
          value={values[field.id] || ""}
          onChange={(val: any) => setValues({ ...values, [field.id]: val })}
        />
      ))}

      <TouchableOpacity activeOpacity={0.85} onPress={handleSubmit} style={styles.buttonWrapper}>
        <LinearGradient
          colors={["#7C3AED", "#D946EF"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={[styles.buttonGradient, { height: screenHeight * 0.06 }]}
        >
          {loading ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            // @ts-ignore
            <Text style={styles.buttonText}>Submit Form</Text>
          )}
        </LinearGradient>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F9FAFB",
    paddingHorizontal: screenWidth * 0.06,
    paddingVertical: screenHeight * 0.03,
  },
  buttonWrapper: {
    borderRadius: 16,
    overflow: "hidden",
    marginTop: 10,
  },
  buttonGradient: {
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 16,
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
});
