import React, { useState, useLayoutEffect } from "react";
import {
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  StyleSheet,
  Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter, useNavigation } from "expo-router";
import { TouchableOpacity as RNTouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { api } from "../../lib/apiClient";
import { ENV } from "../../lib/env";

const { width: screenWidth, height: screenHeight } = Dimensions.get("window");

export default function AddForm() {
  const router = useRouter();
  const navigation = useNavigation();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerShown: true,
      headerLeft: () => (
        <RNTouchableOpacity
          style={styles.headerLeft}
          onPress={() => router.back()}
        >
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </RNTouchableOpacity>
      ),
      title: "📝 Add New Form",
      headerStyle: styles.headerStyle,
      headerTintColor: "#fff",
    });
  }, [navigation, router]);

  const handleSubmit = async () => {
    if (!title.trim()) {
      Alert.alert("Error", "Form title cannot be empty.");
      return;
    }

    setLoading(true);

    try {
      const payload = {
        name: title,
        description: description || "",
        username: ENV.VITE_USERNAME,
      };

      await api.post("/form", payload);

      Alert.alert(
        "Success",
        "Form has been saved successfully!",
        [
          {
            text: "OK",
            onPress: () => router.back(),
          },
        ],
        { cancelable: false }
      );
    } catch (err) {
      if (err instanceof Error) {
        Alert.alert("Error", err.message);
      } else {
        Alert.alert("Error", "Something went wrong");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      {/* Title Input */}
      <View style={[styles.inputContainer, { marginBottom: screenHeight * 0.03 }]}>
        <Text style={styles.label}>Form Title</Text>
        <TextInput
          value={title}
          onChangeText={setTitle}
          placeholder="Enter form title"
          style={styles.input}
          editable={!loading}
        />
      </View>

      {/* Description Input */}
      <View style={[styles.inputContainer, { marginBottom: screenHeight * 0.04 }]}>
        <Text style={styles.label}>Description</Text>
        <TextInput
          value={description}
          onChangeText={setDescription}
          placeholder="Enter form description"
          style={[styles.input, { height: screenHeight * 0.15 }]}
          multiline
          numberOfLines={4}
          textAlignVertical="top"
          editable={!loading}
        />
      </View>

      {/* Save Button */}
      <TouchableOpacity
        activeOpacity={0.85}
        onPress={handleSubmit}
        style={[styles.buttonWrapper, { marginTop: screenHeight * 0.025 }]}
        disabled={loading}
      >
        <LinearGradient
          colors={loading ? ["#A78BFA", "#F9A8D4"] : ["#7C3AED", "#D946EF"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={[styles.buttonGradient, { height: screenHeight * 0.06 }]}
        >
          {loading ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <Text style={styles.buttonText}>Save Form</Text>
          )}
        </LinearGradient>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F9FAFB",
    paddingHorizontal: screenWidth * 0.06,
    paddingVertical: screenHeight * 0.03,
  },
  headerLeft: {
    marginLeft: 15,
  },
  headerStyle: {
    backgroundColor: "#7C3AED",
  },
  inputContainer: {},
  label: {
    fontSize: screenWidth * 0.045,
    color: "#374151",
    fontWeight: "500",
    marginBottom: screenHeight * 0.01,
  },
  input: {
    backgroundColor: "#fff",
    padding: screenHeight * 0.02,
    borderRadius: screenWidth * 0.04,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    fontSize: screenWidth * 0.045,
    color: "#111827",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 2,
  },
  buttonWrapper: {
    borderRadius: screenWidth * 0.06,
    overflow: "hidden",
  },
  buttonGradient: {
    alignItems: "center",
    justifyContent: "center",
    borderRadius: screenWidth * 0.06,
    paddingHorizontal: screenWidth * 0.05,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: screenWidth * 0.048,
  },
});
