import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import FormsList from "../../components/FormsList";
import { useRouter } from "expo-router";
import { Colors } from "../../constants/theme";

export default function FormsListUI() {
  const router = useRouter();
  return (
    <View className="flex-1 p-5" style={{ backgroundColor: Colors.BACKGROUND }}>
      <View className="flex-row justify-between items-center mb-5">
        <Text className="text-3xl font-bold" style={{ color: Colors.TEXT_DARK }}>
          📋 My Forms
        </Text>

        <TouchableOpacity
          onPress={() => router.push("/form/add/[id]")}
          activeOpacity={0.8}
          className="px-4 py-2 rounded-xl shadow-md"
          style={{ backgroundColor: Colors.PRIMARY }}
        >
          <Text className="text-white font-semibold text-lg">+ Add Form</Text>
        </TouchableOpacity>
      </View>

      <FormsList />
    </View>
  );
}
